# """The Color class represents RGBA color values using a value range of 0-255.
# It allows basic arithmetic operations tocreate new colors, supports conversions
# to other color spaces such as HSV or HSL and lets you adjust single color
# channels. Alpha defaults to 255 when not given.

# 'rgbvalue' can be either a color name, an HTML color format string, a hex number
# string, or an integer pixel value. The HTML format is '#rrggbbaa', where rr, gg,
# bb, and aa are 2 digit hex numbers. The alpha aa is optional. A hex number
# string has the form '0xrrggbbaa', where aa is optional.

# If passed an integer, ARGB format is assumed.

# Color objects support equality comparison with other color objects and 3 or 4
# element tuples of integers."""

# from math import floor, pow
# import re

# __all__ = ["colors", "Color", "gamma_decode", "is_rgb_color", "is_rgba_color",
#            "argb_to_color", "ARGB", "rgba_to_color", "RGBA", "string_to_color",
#            "convert_to_color", "COLOR"]

# long = int

# colors = {
#     'gray17': (43, 43, 43, 255),
#     'gold': (255, 215, 0, 255),
#     'gray10': (26, 26, 26, 255),
#     'yellow': (255, 255, 0, 255),
#     'gray11': (28, 28, 28, 255),
#     'grey61': (156, 156, 156, 255),
#     'grey60': (153, 153, 153, 255),
#     'darkseagreen': (143, 188, 143, 255),
#     'grey62': (158, 158, 158, 255),
#     'grey65': (166, 166, 166, 255),
#     'gray12': (31, 31, 31, 255),
#     'grey67': (171, 171, 171, 255),
#     'grey66': (168, 168, 168, 255),
#     'grey69': (176, 176, 176, 255),
#     'gray21': (54, 54, 54, 255),
#     'lightsalmon4': (139, 87, 66, 255),
#     'lightsalmon2': (238, 149, 114, 255),
#     'lightsalmon3': (205, 129, 98, 255),
#     'lightsalmon1': (255, 160, 122, 255),
#     'gray32': (82, 82, 82, 255),
#     'green4': (0, 139, 0, 255),
#     'gray30': (77, 77, 77, 255),
#     'gray31': (79, 79, 79, 255),
#     'green1': (0, 255, 0, 255),
#     'gray37': (94, 94, 94, 255),
#     'green3': (0, 205, 0, 255),
#     'green2': (0, 238, 0, 255),
#     'darkslategray1': (151, 255, 255, 255),
#     'darkslategray2': (141, 238, 238, 255),
#     'darkslategray3': (121, 205, 205, 255),
#     'aquamarine1': (127, 255, 212, 255),
#     'aquamarine3': (102, 205, 170, 255),
#     'aquamarine2': (118, 238, 198, 255),
#     'papayawhip': (255, 239, 213, 255),
#     'black': (0, 0, 0, 255),
#     'darkorange3': (205, 102, 0, 255),
#     'oldlace': (253, 245, 230, 255),
#     'lightgoldenrod4': (139, 129, 76, 255),
#     'gray90': (229, 229, 229, 255),
#     'orchid1': (255, 131, 250, 255),
#     'orchid2': (238, 122, 233, 255),
#     'orchid3': (205, 105, 201, 255),
#     'grey68': (173, 173, 173, 255),
#     'brown': (165, 42, 42, 255),
#     'purple2': (145, 44, 238, 255),
#     'gray80': (204, 204, 204, 255),
#     'antiquewhite3': (205, 192, 176, 255),
#     'antiquewhite2': (238, 223, 204, 255),
#     'antiquewhite1': (255, 239, 219, 255),
#     'palevioletred3': (205, 104, 137, 255),
#     'hotpink': (255, 105, 180, 255),
#     'lightcyan': (224, 255, 255, 255),
#     'coral3': (205, 91, 69, 255),
#     'gray8': (20, 20, 20, 255),
#     'gray9': (23, 23, 23, 255),
#     'grey32': (82, 82, 82, 255),
#     'bisque4': (139, 125, 107, 255),
#     'cyan': (0, 255, 255, 255),
#     'gray0': (0, 0, 0, 255),
#     'gray1': (3, 3, 3, 255),
#     'gray6': (15, 15, 15, 255),
#     'bisque1': (255, 228, 196, 255),
#     'bisque2': (238, 213, 183, 255),
#     'bisque3': (205, 183, 158, 255),
#     'skyblue': (135, 206, 235, 255),
#     'gray': (190, 190, 190, 255),
#     'darkturquoise': (0, 206, 209, 255),
#     'rosybrown4': (139, 105, 105, 255),
#     'deepskyblue3': (0, 154, 205, 255),
#     'grey63': (161, 161, 161, 255),
#     'indianred1': (255, 106, 106, 255),
#     'grey78': (199, 199, 199, 255),
#     'lightpink': (255, 182, 193, 255),
#     'gray88': (224, 224, 224, 255),
#     'gray22': (56, 56, 56, 255),
#     'red': (255, 0, 0, 255),
#     'grey11': (28, 28, 28, 255),
#     'lemonchiffon3': (205, 201, 165, 255),
#     'lemonchiffon2': (238, 233, 191, 255),
#     'lemonchiffon1': (255, 250, 205, 255),
#     'indianred3': (205, 85, 85, 255),
#     'violetred1': (255, 62, 150, 255),
#     'plum2': (238, 174, 238, 255),
#     'plum1': (255, 187, 255, 255),
#     'lemonchiffon4': (139, 137, 112, 255),
#     'gray99': (252, 252, 252, 255),
#     'grey13': (33, 33, 33, 255),
#     'grey55': (140, 140, 140, 255),
#     'darkcyan': (0, 139, 139, 255),
#     'chocolate4': (139, 69, 19, 255),
#     'lightgoldenrodyellow': (250, 250, 210, 255),
#     'gray54': (138, 138, 138, 255),
#     'lavender': (230, 230, 250, 255),
#     'chartreuse3': (102, 205, 0, 255),
#     'chartreuse2': (118, 238, 0, 255),
#     'chartreuse1': (127, 255, 0, 255),
#     'grey48': (122, 122, 122, 255),
#     'grey16': (41, 41, 41, 255),
#     'thistle': (216, 191, 216, 255),
#     'chartreuse4': (69, 139, 0, 255),
#     'darkorchid4': (104, 34, 139, 255),
#     'grey42': (107, 107, 107, 255),
#     'grey41': (105, 105, 105, 255),
#     'grey17': (43, 43, 43, 255),
#     'dimgrey': (105, 105, 105, 255),
#     'dodgerblue4': (16, 78, 139, 255),
#     'darkorchid2': (178, 58, 238, 255),
#     'darkorchid3': (154, 50, 205, 255),
#     'blue': (0, 0, 255, 255),
#     'rosybrown2': (238, 180, 180, 255),
#     'honeydew': (240, 255, 240, 255),
#     'gray18': (46, 46, 46, 255),
#     'cornflowerblue': (100, 149, 237, 255),
#     'grey91': (232, 232, 232, 255),
#     'gray14': (36, 36, 36, 255),
#     'gray15': (38, 38, 38, 255),
#     'gray16': (41, 41, 41, 255),
#     'maroon4': (139, 28, 98, 255),
#     'maroon3': (205, 41, 144, 255),
#     'maroon2': (238, 48, 167, 255),
#     'maroon1': (255, 52, 179, 255),
#     'gray13': (33, 33, 33, 255),
#     'gold3': (205, 173, 0, 255),
#     'gold2': (238, 201, 0, 255),
#     'gold1': (255, 215, 0, 255),
#     'grey79': (201, 201, 201, 255),
#     'palevioletred1': (255, 130, 171, 255),
#     'palevioletred2': (238, 121, 159, 255),
#     'gold4': (139, 117, 0, 255),
#     'gray41': (105, 105, 105, 255),
#     'gray84': (214, 214, 214, 255),
#     'mediumpurple': (147, 112, 219, 255),
#     'rosybrown1': (255, 193, 193, 255),
#     'lightblue2': (178, 223, 238, 255),
#     'lightblue3': (154, 192, 205, 255),
#     'grey57': (145, 145, 145, 255),
#     'lightblue1': (191, 239, 255, 255),
#     'lightblue4': (104, 131, 139, 255),
#     'gray33': (84, 84, 84, 255),
#     'skyblue4': (74, 112, 139, 255),
#     'grey97': (247, 247, 247, 255),
#     'skyblue1': (135, 206, 255, 255),
#     'gray27': (69, 69, 69, 255),
#     'skyblue3': (108, 166, 205, 255),
#     'skyblue2': (126, 192, 238, 255),
#     'lavenderblush1': (255, 240, 245, 255),
#     'darkgrey': (169, 169, 169, 255),
#     'lavenderblush3': (205, 193, 197, 255),
#     'darkslategrey': (47, 79, 79, 255),
#     'lavenderblush4': (139, 131, 134, 255),
#     'deeppink4': (139, 10, 80, 255),
#     'grey99': (252, 252, 252, 255),
#     'gray36': (92, 92, 92, 255),
#     'coral4': (139, 62, 47, 255),
#     'magenta3': (205, 0, 205, 255),
#     'lightskyblue4': (96, 123, 139, 255),
#     'mediumturquoise': (72, 209, 204, 255),
#     'gray34': (87, 87, 87, 255),
#     'floralwhite': (255, 250, 240, 255),
#     'grey39': (99, 99, 99, 255),
#     'grey36': (92, 92, 92, 255),
#     'grey37': (94, 94, 94, 255),
#     'grey34': (87, 87, 87, 255),
#     'gray26': (66, 66, 66, 255),
#     'royalblue2': (67, 110, 238, 255),
#     'grey33': (84, 84, 84, 255),
#     'turquoise1': (0, 245, 255, 255),
#     'grey31': (79, 79, 79, 255),
#     'steelblue1': (99, 184, 255, 255),
#     'sienna4': (139, 71, 38, 255),
#     'steelblue3': (79, 148, 205, 255),
#     'lavenderblush2': (238, 224, 229, 255),
#     'sienna1': (255, 130, 71, 255),
#     'steelblue4': (54, 100, 139, 255),
#     'sienna3': (205, 104, 57, 255),
#     'aquamarine4': (69, 139, 116, 255),
#     'lightyellow1': (255, 255, 224, 255),
#     'lightyellow2': (238, 238, 209, 255),
#     'lightsteelblue': (176, 196, 222, 255),
#     'lightyellow4': (139, 139, 122, 255),
#     'magenta2': (238, 0, 238, 255),
#     'lightskyblue1': (176, 226, 255, 255),
#     'lightgoldenrod': (238, 221, 130, 255),
#     'magenta4': (139, 0, 139, 255),
#     'gray87': (222, 222, 222, 255),
#     'greenyellow': (173, 255, 47, 255),
#     'navajowhite4': (139, 121, 94, 255),
#     'darkslategray4': (82, 139, 139, 255),
#     'olivedrab': (107, 142, 35, 255),
#     'navajowhite1': (255, 222, 173, 255),
#     'navajowhite2': (238, 207, 161, 255),
#     'darkgoldenrod1': (255, 185, 15, 255),
#     'sienna': (160, 82, 45, 255),
#     'blue1': (0, 0, 255, 255),
#     'yellow1': (255, 255, 0, 255),
#     'gray61': (156, 156, 156, 255),
#     'magenta1': (255, 0, 255, 255),
#     'grey52': (133, 133, 133, 255),
#     'orangered4': (139, 37, 0, 255),
#     'palegreen': (152, 251, 152, 255),
#     'gray86': (219, 219, 219, 255),
#     'grey80': (204, 204, 204, 255),
#     'seashell': (255, 245, 238, 255),
#     'royalblue': (65, 105, 225, 255),
#     'firebrick3': (205, 38, 38, 255),
#     'blue4': (0, 0, 139, 255),
#     'peru': (205, 133, 63, 255),
#     'gray60': (153, 153, 153, 255),
#     'aquamarine': (127, 255, 212, 255),
#     'grey53': (135, 135, 135, 255),
#     'tan4': (139, 90, 43, 255),
#     'darkgoldenrod': (184, 134, 11, 255),
#     'tan2': (238, 154, 73, 255),
#     'tan1': (255, 165, 79, 255),
#     'darkslategray': (47, 79, 79, 255),
#     'royalblue3': (58, 95, 205, 255),
#     'red2': (238, 0, 0, 255),
#     'red1': (255, 0, 0, 255),
#     'dodgerblue': (30, 144, 255, 255),
#     'violetred4': (139, 34, 82, 255),
#     'lightyellow': (255, 255, 224, 255),
#     'paleturquoise1': (187, 255, 255, 255),
#     'firebrick2': (238, 44, 44, 255),
#     'mediumaquamarine': (102, 205, 170, 255),
#     'lemonchiffon': (255, 250, 205, 255),
#     'chocolate': (210, 105, 30, 255),
#     'orchid4': (139, 71, 137, 255),
#     'maroon': (176, 48, 96, 255),
#     'gray38': (97, 97, 97, 255),
#     'darkorange4': (139, 69, 0, 255),
#     'mintcream': (245, 255, 250, 255),
#     'darkorange1': (255, 127, 0, 255),
#     'antiquewhite': (250, 235, 215, 255),
#     'darkorange2': (238, 118, 0, 255),
#     'grey18': (46, 46, 46, 255),
#     'grey19': (48, 48, 48, 255),
#     'grey38': (97, 97, 97, 255),
#     'moccasin': (255, 228, 181, 255),
#     'grey10': (26, 26, 26, 255),
#     'chocolate1': (255, 127, 36, 255),
#     'chocolate2': (238, 118, 33, 255),
#     'chocolate3': (205, 102, 29, 255),
#     'saddlebrown': (139, 69, 19, 255),
#     'grey15': (38, 38, 38, 255),
#     'darkslateblue': (72, 61, 139, 255),
#     'lightskyblue': (135, 206, 250, 255),
#     'gray69': (176, 176, 176, 255),
#     'gray68': (173, 173, 173, 255),
#     'deeppink': (255, 20, 147, 255),
#     'gray65': (166, 166, 166, 255),
#     'gray64': (163, 163, 163, 255),
#     'gray67': (171, 171, 171, 255),
#     'gray66': (168, 168, 168, 255),
#     'gray25': (64, 64, 64, 255),
#     'coral': (255, 127, 80, 255),
#     'gray63': (161, 161, 161, 255),
#     'gray62': (158, 158, 158, 255),
#     'goldenrod4': (139, 105, 20, 255),
#     'grey35': (89, 89, 89, 255),
#     'gray89': (227, 227, 227, 255),
#     'goldenrod1': (255, 193, 37, 255),
#     'goldenrod2': (238, 180, 34, 255),
#     'goldenrod3': (205, 155, 29, 255),
#     'springgreen1': (0, 255, 127, 255),
#     'springgreen2': (0, 238, 118, 255),
#     'springgreen3': (0, 205, 102, 255),
#     'springgreen4': (0, 139, 69, 255),
#     'mistyrose1': (255, 228, 225, 255),
#     'sandybrown': (244, 164, 96, 255),
#     'grey30': (77, 77, 77, 255),
#     'seashell2': (238, 229, 222, 255),
#     'seashell3': (205, 197, 191, 255),
#     'tan': (210, 180, 140, 255),
#     'seashell1': (255, 245, 238, 255),
#     'mistyrose3': (205, 183, 181, 255),
#     'magenta': (255, 0, 255, 255),
#     'pink': (255, 192, 203, 255),
#     'ivory2': (238, 238, 224, 255),
#     'ivory1': (255, 255, 240, 255),
#     'lightcyan2': (209, 238, 238, 255),
#     'mediumseagreen': (60, 179, 113, 255),
#     'ivory4': (139, 139, 131, 255),
#     'darkorange': (255, 140, 0, 255),
#     'powderblue': (176, 224, 230, 255),
#     'dodgerblue1': (30, 144, 255, 255),
#     'gray95': (242, 242, 242, 255),
#     'firebrick1': (255, 48, 48, 255),
#     'gray7': (18, 18, 18, 255),
#     'mistyrose4': (139, 125, 123, 255),
#     'tomato': (255, 99, 71, 255),
#     'indianred2': (238, 99, 99, 255),
#     'steelblue2': (92, 172, 238, 255),
#     'gray100': (255, 255, 255, 255),
#     'seashell4': (139, 134, 130, 255),
#     'grey89': (227, 227, 227, 255),
#     'grey88': (224, 224, 224, 255),
#     'grey87': (222, 222, 222, 255),
#     'grey86': (219, 219, 219, 255),
#     'grey85': (217, 217, 217, 255),
#     'grey84': (214, 214, 214, 255),
#     'midnightblue': (25, 25, 112, 255),
#     'grey82': (209, 209, 209, 255),
#     'grey81': (207, 207, 207, 255),
#     'yellow3': (205, 205, 0, 255),
#     'ivory3': (205, 205, 193, 255),
#     'grey22': (56, 56, 56, 255),
#     'gray85': (217, 217, 217, 255),
#     'violetred3': (205, 50, 120, 255),
#     'dodgerblue2': (28, 134, 238, 255),
#     'gray42': (107, 107, 107, 255),
#     'sienna2': (238, 121, 66, 255),
#     'grey72': (184, 184, 184, 255),
#     'grey73': (186, 186, 186, 255),
#     'grey70': (179, 179, 179, 255),
#     'palevioletred': (219, 112, 147, 255),
#     'lightslategray': (119, 136, 153, 255),
#     'grey77': (196, 196, 196, 255),
#     'grey74': (189, 189, 189, 255),
#     'slategray1': (198, 226, 255, 255),
#     'pink1': (255, 181, 197, 255),
#     'mediumpurple1': (171, 130, 255, 255),
#     'pink3': (205, 145, 158, 255),
#     'antiquewhite4': (139, 131, 120, 255),
#     'lightpink1': (255, 174, 185, 255),
#     'honeydew2': (224, 238, 224, 255),
#     'khaki4': (139, 134, 78, 255),
#     'darkolivegreen4': (110, 139, 61, 255),
#     'gray45': (115, 115, 115, 255),
#     'slategray3': (159, 182, 205, 255),
#     'darkolivegreen1': (202, 255, 112, 255),
#     'khaki1': (255, 246, 143, 255),
#     'khaki2': (238, 230, 133, 255),
#     'khaki3': (205, 198, 115, 255),
#     'lavenderblush': (255, 240, 245, 255),
#     'honeydew4': (131, 139, 131, 255),
#     'salmon3': (205, 112, 84, 255),
#     'salmon2': (238, 130, 98, 255),
#     'gray92': (235, 235, 235, 255),
#     'salmon4': (139, 76, 57, 255),
#     'gray49': (125, 125, 125, 255),
#     'gray48': (122, 122, 122, 255),
#     'linen': (250, 240, 230, 255),
#     'burlywood1': (255, 211, 155, 255),
#     'green': (0, 255, 0, 255),
#     'gray47': (120, 120, 120, 255),
#     'blueviolet': (138, 43, 226, 255),
#     'brown2': (238, 59, 59, 255),
#     'brown3': (205, 51, 51, 255),
#     'peachpuff': (255, 218, 185, 255),
#     'brown4': (139, 35, 35, 255),
#     'firebrick4': (139, 26, 26, 255),
#     'azure1': (240, 255, 255, 255),
#     'azure3': (193, 205, 205, 255),
#     'azure2': (224, 238, 238, 255),
#     'azure4': (131, 139, 139, 255),
#     'tomato4': (139, 54, 38, 255),
#     'orange4': (139, 90, 0, 255),
#     'firebrick': (178, 34, 34, 255),
#     'indianred': (205, 92, 92, 255),
#     'orange1': (255, 165, 0, 255),
#     'orange3': (205, 133, 0, 255),
#     'orange2': (238, 154, 0, 255),
#     'darkolivegreen': (85, 107, 47, 255),
#     'gray2': (5, 5, 5, 255),
#     'slategrey': (112, 128, 144, 255),
#     'gray81': (207, 207, 207, 255),
#     'darkred': (139, 0, 0, 255),
#     'gray3': (8, 8, 8, 255),
#     'lightsteelblue1': (202, 225, 255, 255),
#     'lightsteelblue2': (188, 210, 238, 255),
#     'lightsteelblue3': (162, 181, 205, 255),
#     'lightsteelblue4': (110, 123, 139, 255),
#     'tomato3': (205, 79, 57, 255),
#     'gray43': (110, 110, 110, 255),
#     'darkgoldenrod4': (139, 101, 8, 255),
#     'grey50': (127, 127, 127, 255),
#     'yellow4': (139, 139, 0, 255),
#     'mediumorchid': (186, 85, 211, 255),
#     'yellow2': (238, 238, 0, 255),
#     'darkgoldenrod2': (238, 173, 14, 255),
#     'darkgoldenrod3': (205, 149, 12, 255),
#     'chartreuse': (127, 255, 0, 255),
#     'mediumblue': (0, 0, 205, 255),
#     'gray4': (10, 10, 10, 255),
#     'springgreen': (0, 255, 127, 255),
#     'orange': (255, 165, 0, 255),
#     'gray5': (13, 13, 13, 255),
#     'lightsalmon': (255, 160, 122, 255),
#     'gray19': (48, 48, 48, 255),
#     'turquoise': (64, 224, 208, 255),
#     'lightseagreen': (32, 178, 170, 255),
#     'grey8': (20, 20, 20, 255),
#     'grey9': (23, 23, 23, 255),
#     'grey6': (15, 15, 15, 255),
#     'grey7': (18, 18, 18, 255),
#     'grey4': (10, 10, 10, 255),
#     'grey5': (13, 13, 13, 255),
#     'grey2': (5, 5, 5, 255),
#     'grey3': (8, 8, 8, 255),
#     'grey0': (0, 0, 0, 255),
#     'grey1': (3, 3, 3, 255),
#     'gray50': (127, 127, 127, 255),
#     'goldenrod': (218, 165, 32, 255),
#     'grey58': (148, 148, 148, 255),
#     'grey59': (150, 150, 150, 255),
#     'gray51': (130, 130, 130, 255),
#     'grey54': (138, 138, 138, 255),
#     'mediumorchid4': (122, 55, 139, 255),
#     'grey56': (143, 143, 143, 255),
#     'navajowhite3': (205, 179, 139, 255),
#     'mediumorchid1': (224, 102, 255, 255),
#     'grey51': (130, 130, 130, 255),
#     'mediumorchid3': (180, 82, 205, 255),
#     'mediumorchid2': (209, 95, 238, 255),
#     'cyan2': (0, 238, 238, 255),
#     'cyan3': (0, 205, 205, 255),
#     'gray23': (59, 59, 59, 255),
#     'cyan1': (0, 255, 255, 255),
#     'darkgreen': (0, 100, 0, 255),
#     'gray24': (61, 61, 61, 255),
#     'cyan4': (0, 139, 139, 255),
#     'darkviolet': (148, 0, 211, 255),
#     'peachpuff4': (139, 119, 101, 255),
#     'gray28': (71, 71, 71, 255),
#     'slateblue4': (71, 60, 139, 255),
#     'slateblue3': (105, 89, 205, 255),
#     'peachpuff1': (255, 218, 185, 255),
#     'peachpuff2': (238, 203, 173, 255),
#     'peachpuff3': (205, 175, 149, 255),
#     'gray29': (74, 74, 74, 255),
#     'paleturquoise': (175, 238, 238, 255),
#     'darkgray': (169, 169, 169, 255),
#     'grey25': (64, 64, 64, 255),
#     'darkmagenta': (139, 0, 139, 255),
#     'palegoldenrod': (238, 232, 170, 255),
#     'grey64': (163, 163, 163, 255),
#     'grey12': (31, 31, 31, 255),
#     'deeppink3': (205, 16, 118, 255),
#     'gray79': (201, 201, 201, 255),
#     'gray83': (212, 212, 212, 255),
#     'deeppink2': (238, 18, 137, 255),
#     'burlywood4': (139, 115, 85, 255),
#     'palevioletred4': (139, 71, 93, 255),
#     'deeppink1': (255, 20, 147, 255),
#     'slateblue2': (122, 103, 238, 255),
#     'grey46': (117, 117, 117, 255),
#     'royalblue4': (39, 64, 139, 255),
#     'yellowgreen': (154, 205, 50, 255),
#     'royalblue1': (72, 118, 255, 255),
#     'slateblue1': (131, 111, 255, 255),
#     'lightgoldenrod3': (205, 190, 112, 255),
#     'lightgoldenrod2': (238, 220, 130, 255),
#     'navy': (0, 0, 128, 255),
#     'orchid': (218, 112, 214, 255),
#     'ghostwhite': (248, 248, 255, 255),
#     'purple': (160, 32, 240, 255),
#     'darkkhaki': (189, 183, 107, 255),
#     'grey45': (115, 115, 115, 255),
#     'gray94': (240, 240, 240, 255),
#     'wheat4': (139, 126, 102, 255),
#     'gray96': (245, 245, 245, 255),
#     'gray97': (247, 247, 247, 255),
#     'wheat1': (255, 231, 186, 255),
#     'gray91': (232, 232, 232, 255),
#     'wheat3': (205, 186, 150, 255),
#     'wheat2': (238, 216, 174, 255),
#     'indianred4': (139, 58, 58, 255),
#     'coral2': (238, 106, 80, 255),
#     'coral1': (255, 114, 86, 255),
#     'violetred': (208, 32, 144, 255),
#     'rosybrown3': (205, 155, 155, 255),
#     'deepskyblue2': (0, 178, 238, 255),
#     'deepskyblue1': (0, 191, 255, 255),
#     'bisque': (255, 228, 196, 255),
#     'grey49': (125, 125, 125, 255),
#     'khaki': (240, 230, 140, 255),
#     'wheat': (245, 222, 179, 255),
#     'lightslateblue': (132, 112, 255, 255),
#     'mediumpurple3': (137, 104, 205, 255),
#     'gray55': (140, 140, 140, 255),
#     'deepskyblue': (0, 191, 255, 255),
#     'gray98': (250, 250, 250, 255),
#     'steelblue': (70, 130, 180, 255),
#     'aliceblue': (240, 248, 255, 255),
#     'lightskyblue2': (164, 211, 238, 255),
#     'lightskyblue3': (141, 182, 205, 255),
#     'lightslategrey': (119, 136, 153, 255),
#     'blue3': (0, 0, 205, 255),
#     'blue2': (0, 0, 238, 255),
#     'gainsboro': (220, 220, 220, 255),
#     'grey76': (194, 194, 194, 255),
#     'purple3': (125, 38, 205, 255),
#     'plum4': (139, 102, 139, 255),
#     'gray56': (143, 143, 143, 255),
#     'plum3': (205, 150, 205, 255),
#     'plum': (221, 160, 221, 255),
#     'lightgrey': (211, 211, 211, 255),
#     'mediumslateblue': (123, 104, 238, 255),
#     'mistyrose': (255, 228, 225, 255),
#     'lightcyan1': (224, 255, 255, 255),
#     'grey71': (181, 181, 181, 255),
#     'darksalmon': (233, 150, 122, 255),
#     'beige': (245, 245, 220, 255),
#     'grey24': (61, 61, 61, 255),
#     'azure': (240, 255, 255, 255),
#     'honeydew1': (240, 255, 240, 255),
#     'slategray2': (185, 211, 238, 255),
#     'dodgerblue3': (24, 116, 205, 255),
#     'slategray4': (108, 123, 139, 255),
#     'grey27': (69, 69, 69, 255),
#     'lightcyan3': (180, 205, 205, 255),
#     'cornsilk': (255, 248, 220, 255),
#     'tomato1': (255, 99, 71, 255),
#     'gray57': (145, 145, 145, 255),
#     'mediumvioletred': (199, 21, 133, 255),
#     'tomato2': (238, 92, 66, 255),
#     'snow4': (139, 137, 137, 255),
#     'grey75': (191, 191, 191, 255),
#     'snow2': (238, 233, 233, 255),
#     'snow3': (205, 201, 201, 255),
#     'snow1': (255, 250, 250, 255),
#     'grey23': (59, 59, 59, 255),
#     'cornsilk3': (205, 200, 177, 255),
#     'lightcoral': (240, 128, 128, 255),
#     'orangered': (255, 69, 0, 255),
#     'navajowhite': (255, 222, 173, 255),
#     'mediumpurple2': (159, 121, 238, 255),
#     'slategray': (112, 128, 144, 255),
#     'pink2': (238, 169, 184, 255),
#     'grey29': (74, 74, 74, 255),
#     'grey28': (71, 71, 71, 255),
#     'gray82': (209, 209, 209, 255),
#     'burlywood': (222, 184, 135, 255),
#     'mediumpurple4': (93, 71, 139, 255),
#     'mediumspringgreen': (0, 250, 154, 255),
#     'grey26': (66, 66, 66, 255),
#     'grey21': (54, 54, 54, 255),
#     'grey20': (51, 51, 51, 255),
#     'blanchedalmond': (255, 235, 205, 255),
#     'pink4': (139, 99, 108, 255),
#     'gray78': (199, 199, 199, 255),
#     'tan3': (205, 133, 63, 255),
#     'gray76': (194, 194, 194, 255),
#     'gray77': (196, 196, 196, 255),
#     'white': (255, 255, 255, 255),
#     'gray75': (191, 191, 191, 255),
#     'gray72': (184, 184, 184, 255),
#     'gray73': (186, 186, 186, 255),
#     'gray70': (179, 179, 179, 255),
#     'gray71': (181, 181, 181, 255),
#     'lightgray': (211, 211, 211, 255),
#     'ivory': (255, 255, 240, 255),
#     'gray46': (117, 117, 117, 255),
#     'gray74': (189, 189, 189, 255),
#     'lightyellow3': (205, 205, 180, 255),
#     'lightpink2': (238, 162, 173, 255),
#     'lightpink3': (205, 140, 149, 255),
#     'paleturquoise4': (102, 139, 139, 255),
#     'lightpink4': (139, 95, 101, 255),
#     'paleturquoise3': (150, 205, 205, 255),
#     'seagreen4': (46, 139, 87, 255),
#     'seagreen3': (67, 205, 128, 255),
#     'seagreen2': (78, 238, 148, 255),
#     'seagreen1': (84, 255, 159, 255),
#     'paleturquoise2': (174, 238, 238, 255),
#     'gray52': (133, 133, 133, 255),
#     'cornsilk4': (139, 136, 120, 255),
#     'cornsilk2': (238, 232, 205, 255),
#     'darkolivegreen3': (162, 205, 90, 255),
#     'cornsilk1': (255, 248, 220, 255),
#     'limegreen': (50, 205, 50, 255),
#     'darkolivegreen2': (188, 238, 104, 255),
#     'grey': (190, 190, 190, 255),
#     'violetred2': (238, 58, 140, 255),
#     'salmon1': (255, 140, 105, 255),
#     'grey92': (235, 235, 235, 255),
#     'grey93': (237, 237, 237, 255),
#     'grey94': (240, 240, 240, 255),
#     'grey95': (242, 242, 242, 255),
#     'grey96': (245, 245, 245, 255),
#     'grey83': (212, 212, 212, 255),
#     'grey98': (250, 250, 250, 255),
#     'lightgoldenrod1': (255, 236, 139, 255),
#     'palegreen1': (154, 255, 154, 255),
#     'red3': (205, 0, 0, 255),
#     'palegreen3': (124, 205, 124, 255),
#     'palegreen2': (144, 238, 144, 255),
#     'palegreen4': (84, 139, 84, 255),
#     'cadetblue': (95, 158, 160, 255),
#     'violet': (238, 130, 238, 255),
#     'mistyrose2': (238, 213, 210, 255),
#     'slateblue': (106, 90, 205, 255),
#     'grey43': (110, 110, 110, 255),
#     'grey90': (229, 229, 229, 255),
#     'gray35': (89, 89, 89, 255),
#     'turquoise3': (0, 197, 205, 255),
#     'turquoise2': (0, 229, 238, 255),
#     'burlywood3': (205, 170, 125, 255),
#     'burlywood2': (238, 197, 145, 255),
#     'lightcyan4': (122, 139, 139, 255),
#     'rosybrown': (188, 143, 143, 255),
#     'turquoise4': (0, 134, 139, 255),
#     'whitesmoke': (245, 245, 245, 255),
#     'lightblue': (173, 216, 230, 255),
#     'grey40': (102, 102, 102, 255),
#     'gray40': (102, 102, 102, 255),
#     'honeydew3': (193, 205, 193, 255),
#     'dimgray': (105, 105, 105, 255),
#     'grey47': (120, 120, 120, 255),
#     'seagreen': (46, 139, 87, 255),
#     'red4': (139, 0, 0, 255),
#     'grey14': (36, 36, 36, 255),
#     'snow': (255, 250, 250, 255),
#     'darkorchid1': (191, 62, 255, 255),
#     'gray58': (148, 148, 148, 255),
#     'gray59': (150, 150, 150, 255),
#     'cadetblue4': (83, 134, 139, 255),
#     'cadetblue3': (122, 197, 205, 255),
#     'cadetblue2': (142, 229, 238, 255),
#     'cadetblue1': (152, 245, 255, 255),
#     'olivedrab4': (105, 139, 34, 255),
#     'purple4': (85, 26, 139, 255),
#     'gray20': (51, 51, 51, 255),
#     'grey44': (112, 112, 112, 255),
#     'purple1': (155, 48, 255, 255),
#     'olivedrab1': (192, 255, 62, 255),
#     'olivedrab2': (179, 238, 58, 255),
#     'olivedrab3': (154, 205, 50, 255),
#     'orangered3': (205, 55, 0, 255),
#     'orangered2': (238, 64, 0, 255),
#     'orangered1': (255, 69, 0, 255),
#     'darkorchid': (153, 50, 204, 255),
#     'thistle3': (205, 181, 205, 255),
#     'thistle2': (238, 210, 238, 255),
#     'thistle1': (255, 225, 255, 255),
#     'salmon': (250, 128, 114, 255),
#     'gray93': (237, 237, 237, 255),
#     'thistle4': (139, 123, 139, 255),
#     'gray39': (99, 99, 99, 255),
#     'lawngreen': (124, 252, 0, 255),
#     'hotpink3': (205, 96, 144, 255),
#     'hotpink2': (238, 106, 167, 255),
#     'hotpink1': (255, 110, 180, 255),
#     'lightgreen': (144, 238, 144, 255),
#     'hotpink4': (139, 58, 98, 255),
#     'darkseagreen4': (105, 139, 105, 255),
#     'darkseagreen3': (155, 205, 155, 255),
#     'darkseagreen2': (180, 238, 180, 255),
#     'darkseagreen1': (193, 255, 193, 255),
#     'deepskyblue4': (0, 104, 139, 255),
#     'gray44': (112, 112, 112, 255),
#     'navyblue': (0, 0, 128, 255),
#     'darkblue': (0, 0, 139, 255),
#     'forestgreen': (34, 139, 34, 255),
#     'gray53': (135, 135, 135, 255),
#     'grey100': (255, 255, 255, 255),
#     'brown1': (255, 64, 64, 255),
# }


# class Color:
#     """Color(red, green, blue, alpha)

#     Color(red, green, blue)

#     Color(name)

#     Color("#rrggbbaa")

#     Color("0xrrggbbaa")

#     Color(argb_int)

#     Color(argb_hex)

#     Color(object)

#     Color() -> Color('black')

#     Args:
#         args (tuple): red, green, blue [, alpha].  See argb_to_color().

#         args (string): Color name from pygame2.color.colors

#         args (string): HTML or hex color string.  See string_to_color().
#     """
#     def __init__(self, *args):
#         self._length = 4
#         if len(args) == 4:
#             r, g, b, a = args
#         elif len(args) == 3:
#             r, g, b = args
#             a = 255
#             self._length = 3
#         elif len(args) == 1 \
#                 and hasattr(args[0], 'lower') \
#                 and re.sub(r'\s+', '', args[0].lower()) in colors:
#             # Color name string passed
#             s = re.sub(r'\s+', '', args[0].lower())
#             r, g, b, a = colors[s]
#         elif len(args) == 1:
#             # Otherwise try to convert whatever they passed
#             c = convert_to_color(args[0])
#             r, g, b, a = c.r, c.g, c.b, c.a
#         elif len(args) == 0:
#             r, g, b, a = colors['black']
#         else:
#             raise ValueError("Invalid arguments passed to Color initializer")
#         for c in (r, g, b, a):
#             if c < 0 or c > 255:
#                 raise ValueError("r must be in the range [0; 255]")
#         self._r = int(r)
#         self._g = int(g)
#         self._b = int(b)
#         self._a = int(a)

#     def __copy__(self):
#         if self.length == 4:
#             return self.r, self.g, self.b, self.a
#         if self.length == 3:
#             return self.r, self.g, self.b
#         if self.length == 2:
#             return self.r, self.g
#         if self.length == 1:
#             return self.r

#     #def __hash__(self):
#     #    return self.__index__()

#     def __iter__(self):
#         yield self.r
#         if self.length > 1:
#             yield self.g
#         if self.length > 2:
#             yield self.b
#         if self.length > 3:
#             yield self.a

#     def __len__(self):
#         return self.length

#     def __reversed__(self):
#         if self.length == 4:
#             yield self.a
#             yield self.b
#             yield self.g
#             yield self.r
#         elif self.length == 3:
#             yield self.b
#             yield self.g
#             yield self.r
#         elif self.length == 2:
#             yield self.g
#             yield self.r
#         elif self.length == 1:
#             yield self.r

#     def __repr__(self):
#         return "({0}, {1}, {2}, {3})".format(self.r, self.g, self.b, self.a)

#     def __str__(self):
#         return "Color(r={0}, g={1}, b={2}, a={3})".format(
#             self.r, self.g, self.b, self.a)

#     def __eq__(self, color):
#         if isinstance(color, (tuple, Color, Color)):
#             return self.r == color[0] and self.g == color[1] and \
#                  self.b == color[2] and self.a == color[3]
#         else:
#             return False

#     def __ne__(self, color):
#         if isinstance(color, (tuple, Color, Color)):
#             return self.r != color[0] or self.g != color[1] or \
#                  self.b != color[2] or self.a != color[3]
#         else:
#             return True

#     def __int__(self):
#         return self.r << 24 | self.g << 16 | self.b << 8 | self.a

#     def __float__(self):
#         return (self.r << 24 | self.g << 16 | self.b << 8 | self.a) * 1.0

#     def __index__(self):
#         return self.r << 24 | self.g << 16 | self.b << 8 | self.a

#     def __invert__(self):
#         vals = 255 - self.r, 255 - self.g, 255 - self.b, 255 - self.a
#         return Color(vals[0], vals[1], vals[2], vals[3])

#     def __mod__(self, color):
#         vals = (self.r % color.r, self.g % color.g, self.b % color.b,
#                 self.a % color.a)
#         return Color(vals[0], vals[1], vals[2], vals[3])

#     def __truediv__(self, color):
#         vals = [self.r, self.g, self.b, self.a]
#         if color.r != 0:
#             vals[0] = self.r / color.r
#         if color.g != 0:
#             vals[1] = self.g / color.g
#         if color.b != 0:
#             vals[2] = self.b / color.b
#         if color.a != 0:
#             vals[3] = self.a / color.a
#         return Color(vals[0], vals[1], vals[2], vals[3])

#     def __mul__(self, color):
#         vals = (min(self.r * color.r, 255), min(self.g * color.g, 255),
#                 min(self.b * color.b, 255), min(self.a * color.a, 255))
#         return Color(vals[0], vals[1], vals[2], vals[3])

#     def __sub__(self, color):
#         vals = (max(self.r - color.r, 0), max(self.g - color.g, 0),
#                 max(self.b - color.b, 0), max(self.a - color.a, 0))
#         return Color(vals[0], vals[1], vals[2], vals[3])

#     def __add__(self, color):
#         vals = (min(self.r + color.r, 255), min(self.g + color.g, 255),
#                 min(self.b + color.b, 255), min(self.a + color.a, 255))
#         return Color(vals[0], vals[1], vals[2], vals[3])

#     def __getitem__(self, index):
#         return (self.r, self.g, self.b, self.a)[index]

#     def __setitem__(self, index, val):
#         tmp = [self.r, self.g, self.b, self.a]
#         tmp[index] = val
#         self.r = tmp[0]
#         self.g = tmp[1]
#         self.b = tmp[2]
#         self.a = tmp[3]

#     def __floordiv__(self, color):
#         vals = [self.r, self.g, self.b, self.a]
#         if color.r != 0:
#             vals[0] = self.r // color.r
#         if color.g != 0:
#             vals[1] = self.g // color.g
#         if color.b != 0:
#             vals[2] = self.b // color.b
#         if color.a != 0:
#             vals[3] = self.a // color.a
#         return Color(vals[0], vals[1], vals[2], vals[3])

#     @property
#     def length(self):
#         """The default Color length is 4. Colors can have lengths 1,2,3 or 4.
#         This is useful if you want to unpack to r,g,b and not r,g,b,a. If you
#         want to get the length of a Color do len(acolor)."""
#         return self._length

#     @length.setter
#     def length(self, val):
#         """The default Color length is 4. Colors can have lengths 1,2,3 or 4.
#         This is useful if you want to unpack to r,g,b and not r,g,b,a. If you
#         want to get the length of a Color do len(acolor)."""
#         if type(val) not in (int, long) or val < 1 or val > 4:
#             raise ValueError("Length must be from 1 to 4")
#         self._length = val

#     @property
#     def r(self):
#         """Gets or sets the red value of the Color.
#         ::

#             r -> int"""
#         return self._r

#     @r.setter
#     def r(self, val):
#         """Gets or sets the red value of the Color.
#         ::

#             r -> int"""
#         if type(val) not in(int, long):
#             raise TypeError("value must be an int")
#         if val < 0 or val > 255:
#             raise ValueError("The value must be in the range [0; 255]")
#         self._r = val

#     @property
#     def g(self):
#         """Gets or sets the green value of the Color.
#         ::

#             g -> int"""
#         return self._g

#     @g.setter
#     def g(self, val):
#         """Gets or sets the green value of the Color.
#         ::

#             g -> int"""
#         if type(val) not in(int, long):
#             raise TypeError("value must be an int")
#         if val < 0 or val > 255:
#             raise ValueError("The value must be in the range [0; 255]")
#         self._g = val

#     @property
#     def b(self):
#         """Gets or sets the blue value of the Color.
#         ::

#             b -> int"""
#         return self._b

#     @b.setter
#     def b(self, val):
#         """Gets or sets the blue value of the Color.
#         ::

#             b -> int"""
#         if type(val) not in(int, long):
#             raise TypeError("value must be an int")
#         if val < 0 or val > 255:
#             raise ValueError("The value must be in the range [0; 255]")
#         self._b = val

#     @property
#     def a(self):
#         """Gets or sets the alpha value of the Color.
#         ::

#             a -> int"""
#         return self._a

#     @a.setter
#     def a(self, val):
#         """Gets or sets the alpha value of the Color.
#         ::

#             a -> int"""
#         if type(val) not in(int, long):
#             raise TypeError("value must be an int")
#         if val < 0 or val > 255:
#             raise ValueError("The value must be in the range [0; 255]")
#         self._a = val

#     @property
#     def hsva(self):
#         """The Color as HSVA value.
#         ::

#             hsva -> tuple

#         The HSVA representation of the Color. The HSVA components are in the
#         ranges H = [0, 360], S = [0, 100], V = [0, 100], A = [0, 100]. Note that
#         this will not return the absolutely exact HSV values for the set RGB
#         values in all cases. Due to the RGB mapping from 0-255 and the HSV
#         mapping from 0-100 and 0-360 rounding errors may cause the HSV values to
#         differ slightly from what you might expect."""
#         rn = self.r / 255.0
#         gn = self.g / 255.0
#         bn = self.b / 255.0
#         an = self.a / 255.0

#         maxv = max(rn, gn, bn)
#         minv = min(rn, gn, bn)
#         diff = maxv - minv

#         h = 0
#         s = 0
#         v = maxv * 100.0
#         a = an * 100.0

#         if maxv == minv:
#             return(h, s, v, a)
#         s = 100.0 * (maxv - minv) / maxv

#         if maxv == rn:
#             h = (60 * (gn - bn) / diff) % 360.0
#         elif maxv == gn:
#             h = (60 * (bn - rn) / diff) + 120.0
#         else:
#             h = (60 * (rn - gn) / diff) + 240.0
#         if h < 0:
#             h += 360.0
#         return (h, s, v, a)

#     @hsva.setter
#     def hsva(self, value):
#         """The Color as HSVA value.
#         ::

#             hsva -> tuple

#         The HSVA representation of the Color. The HSVA components are in the
#         ranges H = [0, 360], S = [0, 100], V = [0, 100], A = [0, 100]. Note that
#         this will not return the absolutely exact HSV values for the set RGB
#         values in all cases. Due to the RGB mapping from 0-255 and the HSV
#         mapping from 0-100 and 0-360 rounding errors may cause the HSV values to
#         differ slightly from what you might expect."""
#         h, s, v, a = value
#         for x in (h, s, v, a):
#             if type(x) not in(int, long, float):
#                 raise TypeError("HSVA values must be of type float")
#         if not (0 <= s <= 100) or not (0 <= v <= 100) or \
#                 not (0 <= a <= 100) or not (0 <= h <= 360):
#             raise ValueError("invalid HSVA value")

#         self.a = int((a / 100.0) * 255)
#         s /= 100.0
#         v /= 100.0

#         hi = int(floor(h / 60.0))
#         f = (h / 60.0) - hi
#         p = v * (1 - s)
#         q = v * (1 - s * f)
#         t = v * (1 - s * (1 - f))
#         if hi == 0:
#             self.r = int(v * 255)
#             self.g = int(t * 255)
#             self.b = int(p * 255)
#         elif hi == 1:
#             self.r = int(q * 255)
#             self.g = int(v * 255)
#             self.b = int(p * 255)
#         elif hi == 2:
#             self.r = int(p * 255)
#             self.g = int(v * 255)
#             self.b = int(t * 255)
#         elif hi == 3:
#             self.r = int(p * 255)
#             self.g = int(q * 255)
#             self.b = int(v * 255)
#         elif hi == 4:
#             self.r = int(t * 255)
#             self.g = int(p * 255)
#             self.b = int(v * 255)
#         elif hi == 5:
#             self.r = int(v * 255)
#             self.g = int(p * 255)
#             self.b = int(q * 255)
#         else:
#             raise ValueError("invalid HSVA value")

#     @property
#     def hsla(self):
#         """Gets or sets the HSLA representation of the Color.
#         ::

#             hsla -> tuple

#         The HSLA representation of the Color. The HSLA components are in the
#         ranges H = [0, 360], S = [0, 100], V = [0, 100], A = [0, 100]. Note that
#         this will not return the absolutely exact HSL values for the set RGB
#         values in all cases. Due to the RGB mapping from 0-255 and the HSL
#         mapping from 0-100 and 0-360 rounding errors may cause the HSL values to
#         differ slightly from what you might expect."""
#         rn = self.r / 255.0
#         gn = self.g / 255.0
#         bn = self.b / 255.0
#         an = self.a / 255.0

#         maxv = max(rn, gn, bn)
#         minv = min(rn, gn, bn)
#         diff = maxv - minv

#         h = 0
#         s = 0
#         l = 50.0 * (maxv + minv)
#         a = an * 100.0

#         if maxv == minv:
#             return(h, s, l, a)

#         if l <= 50.0:
#             s = diff / (maxv + minv) * 100.0
#         else:
#             s = diff / (2.0 - maxv - minv) * 100.0

#         if maxv == rn:
#             h = (60 * (gn - bn) / diff) % 360.0
#         elif maxv == gn:
#             h = (60 * (bn - rn) / diff) + 120.0
#         else:
#             h = (60 * (rn - gn) / diff) + 240.0
#         if h < 0:
#             h += 360.0
#         return (h, s, l, a)

#     @hsla.setter
#     def hsla(self, value):
#         """Gets or sets the HSLA representation of the Color.
#         ::

#             hsla -> tuple

#         The HSLA representation of the Color. The HSLA components are in the
#         ranges H = [0, 360], S = [0, 100], V = [0, 100], A = [0, 100]. Note that
#         this will not return the absolutely exact HSL values for the set RGB
#         values in all cases. Due to the RGB mapping from 0-255 and the HSL
#         mapping from 0-100 and 0-360 rounding errors may cause the HSL values to
#         differ slightly from what you might expect."""
#         h, s, l, a = value
#         for x in (h, s, l, a):
#             if type(x) not in (int, long, float):
#                 raise TypeError("HSLA values must be of type float")
#         if not (0 <= s <= 100) or not (0 <= l <= 100) or \
#                 not (0 <= a <= 100) or not (0 <= h <= 360):
#             raise ValueError("invalid HSLA value")

#         self.a = int((a / 100.0) * 255)

#         s /= 100.0
#         l /= 100.0

#         if s == 0:
#             self.r = int(l * 255)
#             self.g = int(l * 255)
#             self.b = int(l * 255)
#             return

#         q = 0
#         if l < 0.5:
#             q = l * (1 + s)
#         else:
#             q = l + s - (l * s)
#         p = 2 * l - q

#         ht = h / 360.0

#         # r
#         h = ht + (1.0 / 3.0)
#         if h < 0:
#             h += 1
#         elif h > 1:
#             h -= 1

#         if h < (1.0 / 6.0):
#             self.r = int((p + ((q - p) * 6 * h)) * 255)
#         elif h < 0.5:
#             self.r = int(q * 255)
#         elif h < (2.0 / 3.0):
#             self.r = int((p + ((q - p) * 6 * (2.0 / 3.0 - h))) * 255)
#         else:
#             self.r = int(p * 255)

#         # g
#         h = ht
#         if h < 0:
#             h += 1
#         elif h > 1:
#             h -= 1

#         if h < (1.0 / 6.0):
#             self.g = int((p + ((q - p) * 6 * h)) * 255)
#         elif h < 0.5:
#             self.g = int(q * 255)
#         elif h < (2.0 / 3.0):
#             self.g = int((p + ((q - p) * 6 * (2.0 / 3.0 - h))) * 255)
#         else:
#             self.g = int(p * 255)

#         # b
#         h = ht - (1.0 / 3.0)
#         if h < 0:
#             h += 1
#         elif h > 1:
#             h -= 1

#         if h < (1.0 / 6.0):
#             self.b = int((p + ((q - p) * 6 * h)) * 255)
#         elif h < 0.5:
#             self.b = int(q * 255)
#         elif h < (2.0 / 3.0):
#             self.b = int((p + ((q - p) * 6 * (2.0 / 3.0 - h))) * 255)
#         else:
#             self.b = int(p * 255)

#     @property
#     def i1i2i3(self):
#         """Gets or sets the I1I2I3 representation of the Color.
#         ::

#             i1i2i3 -> tuple

#         The I1I2I3 representation of the Color. The I1I2I3 components are in the
#         ranges I1 = [0, 1], I2 = [-0.5, 0.5], I3 = [-0.5, 0.5]. Note that this
#         will not return the absolutely exact I1I2I3 values for the set RGB
#         values in all cases. Due to the RGB mapping from 0-255 and the I1I2I3
#         mapping from 0-1 rounding errors may cause the I1I2I3 values to differ
#         slightly from what you might expect."""
#         rn = self.r / 255.0
#         gn = self.g / 255.0
#         bn = self.b / 255.0

#         i1 = (rn + gn + bn) / 3.0
#         i2 = (rn - bn) / 2.0
#         i3 = (2 * gn - rn - bn) / 4.0

#         return(i1, i2, i3)

#     @i1i2i3.setter
#     def i1i2i3(self, value):
#         """Gets or sets the I1I2I3 representation of the Color.
#         ::

#             i1i2i3 -> tuple

#         The I1I2I3 representation of the Color. The I1I2I3 components are in the
#         ranges I1 = [0, 1], I2 = [-0.5, 0.5], I3 = [-0.5, 0.5]. Note that this
#         will not return the absolutely exact I1I2I3 values for the set RGB
#         values in all cases. Due to the RGB mapping from 0-255 and the I1I2I3
#         mapping from 0-1 rounding errors may cause the I1I2I3 values to differ
#         slightly from what you might expect."""
#         i1, i2, i3 = value
#         for x in (i1, i2, i3):
#             if type(x) not in (int, long, float):
#                 raise TypeError("I1I2I3 values must be of type float")
#         if not (0 <= i1 <= 1) or not (-0.5 <= i2 <= 0.5) or \
#                 not (-0.5 <= i3 <= 0.5):
#             raise ValueError("invalid I1I2I3 value")

#         ab = i1 - i2 - 2 * i3 / 3.0
#         ar = 2 * i2 + ab
#         ag = 3 * i1 - ar - ab

#         self.r = int(ar * 255)
#         self.g = int(ag * 255)
#         self.b = int(ab * 255)

#     @property
#     def cmy(self):
#         """Gets or sets the CMY representation of the Color.
#         ::

#             cmy -> tuple

#         The CMY representation of the Color. The CMY components are in the
#         ranges C = [0, 1], M = [0, 1], Y = [0, 1]. Note that this will not
#         return the absolutely exact CMY values for the set RGB values in all
#         cases. Due to the RGB mapping from 0-255 and the CMY mapping from 0-1
#         rounding errors may cause the CMY values to differ slightly from what
#         you might expect."""
#         return (1.0 - self.r / 255.0,
#                 1.0 - self.g / 255.0,
#                 1.0 - self.b / 255.0)

#     @cmy.setter
#     def cmy(self, value):
#         """Gets or sets the CMY representation of the Color.
#         ::

#             cmy -> tuple

#         The CMY representation of the Color. The CMY components are in the
#         ranges C = [0, 1], M = [0, 1], Y = [0, 1]. Note that this will not
#         return the absolutely exact CMY values for the set RGB values in all
#         cases. Due to the RGB mapping from 0-255 and the CMY mapping from 0-1
#         rounding errors may cause the CMY values to differ slightly from what
#         you might expect."""
#         c, m, y = value
#         if (c < 0 or c > 1) or (m < 0 or m > 1) or (y < 0 or y > 1):
#             raise ValueError("invalid CMY value")
#         self.r = int((1.0 - c) * 255)
#         self.g = int((1.0 - m) * 255)
#         self.b = int((1.0 - y) * 255)

#     def normalize(self):
#         """Returns the RGBA values in a normalized form with the range
#         [0;1] as tuple.
#         ::

#             normalize() -> tuple
#         """
#         return (self.r / 255.0, self.g / 255.0, self.b / 255.0, self.a / 255.0)

#     def correct_gamma(self, gamma):
#         """Applies a certain gamma value to the Color.
#         ::

#             correct_gamma (gamma) -> Color

#         Applies a certain gamma value to the Color and returns a new Color with
#         the adjusted RGBA values."""

#         def decode(color):
#             return gamma_decode(color, gamma)

#         colors = list(map(decode, [self.r, self.g, self.b, self.a]))

#         return Color(colors)

#     def set_length(self, length):
#         """The default Color length is 4. Colors can have lengths 1,2,3 or 4.
#         This is useful if you want to unpack to r,g,b and not r,g,b,a. If you
#         want to get the length of a Color do len(acolor).

#         This method is just a pygame1 compatibility function.

#         acolor.length = 4 is equivalent to acolor.set_length(4)"""
#         self.length = length


# def gamma_decode(color, gamma):
#     corrected = round(255 * pow(color/255, gamma))
#     return max(min(int(corrected), 255), 0)


# def is_rgb_color(v):
#     """Checks, if the passed value is an item that could be converted to
#     a RGB color.
#     """
#     try:
#         if hasattr(v, "r") and hasattr(v, "g") and hasattr(v, "b"):
#             if 0 <= int(v.r) <= 255 and 0 <= int(v.g) <= 255 and \
#                     0 <= v.b <= 255:
#                 return True

#         if len(v) >= 3:
#             if 0 <= int(v[0]) <= 255 and 0 <= int(v[1]) <= 255 and \
#                     0 < int(v[2]) < 255:
#                 return True
#         return False
#     except (TypeError, ValueError):
#         return False


# def is_rgba_color(v):
#     """Checks, if the passed value is an item that could be converted to
#     a RGBA color."""
#     rgb = is_rgb_color(v)
#     if not rgb:
#         return False

#     try:
#         if hasattr(v, "a") and 0 <= int(v.a) <= 255:
#             return True
#         if len(v) >= 4 and 0 <= int(v[3]) <= 255:
#             return True
#         return False
#     except (TypeError, ValueError):
#         return False


# def argb_to_color(v):
#     """Converts an integer value to a Color, assuming the integer
#     represents a 32-bit ARGB value."""
#     v = long(v)

#     a = ((v & 0xFF000000) >> 24)
#     r = ((v & 0x00FF0000) >> 16)
#     g = ((v & 0x0000FF00) >> 8)
#     b = (v & 0x000000FF)
#     return Color(r, g, b, a)


# def rgba_to_color(v):
#     """Converts an integer value to a Color, assuming the integer
#     represents a 32-bit RGBA value."""
#     v = long(v)

#     r = ((v & 0xFF000000) >> 24)
#     g = ((v & 0x00FF0000) >> 16)
#     b = ((v & 0x0000FF00) >> 8)
#     a = (v & 0x000000FF)
#     return Color(r, g, b, a)


# def string_to_color(s):
#     """Converts a hex color string or color name to a Color value.

#     Supported hex values are:

#     #RGB
#     #RGBA
#     #RRGGBB
#     #RRGGBBAA

#     0xRGB
#     0xRGBA
#     0xRRGGBB
#     0xRRGGBBAA"""
#     if type(s) is not str:
#         raise TypeError("s must be a string")

#     if not(s.startswith("#") or s.startswith("0x")):
#         raise ValueError("value is not Color-compatible")

#     if s.startswith("#"):
#         s = s[1:]
#     else:
#         s = s[2:]

#     r, g, b, a = 255, 255, 255, 255
#     if len(s) in (3, 4):
#         # A triple/quadruple in the form #ead == #eeaadd
#         r = int(s[0], 16) << 4 | int(s[0], 16)
#         g = int(s[1], 16) << 4 | int(s[1], 16)
#         b = int(s[2], 16) << 4 | int(s[2], 16)
#         if len(s) == 4:
#             a = int(s[3], 16) << 4 | int(s[3], 16)
#     elif len(s) in (6, 8):
#         r = int(s[0], 16) << 4 | int(s[1], 16)
#         g = int(s[2], 16) << 4 | int(s[3], 16)
#         b = int(s[4], 16) << 4 | int(s[5], 16)
#         if len(s) == 8:
#             a = int(s[6], 16) << 4 | int(s[7], 16)
#     else:
#         raise ValueError("value is not Color-compatible")
#     return Color(r, g, b, a)


# def convert_to_color(v):
#     """Tries to convert the passed value to a Color object.

#     If the color is an integer value, it is assumed to be in ARGB layout."""
#     if isinstance(v, Color):
#         return v

#     if type(v) is str:
#         return string_to_color(v)
#     if type(v) in (int, long):
#         return argb_to_color(v)

#     r, g, b, a = 0, 0, 0, 0
#     if hasattr(v, "r") and hasattr(v, "g") and hasattr(v, "b"):
#         if 0 <= int(v.r) <= 255 and 0 <= int(v.g) <= 255 and \
#                 0 <= v.b <= 255:
#             r = int(v.r)
#             g = int(v.g)
#             b = int(v.b)
#             if hasattr(v, "a") and 0 <= int(v.a) <= 255:
#                 a = int(v.a)
#         else:
#             raise ValueError("value is not Color-compatible")
#         return Color(r, g, b, a)

#     try:
#         length = len(v)
#     except:
#         raise ValueError("value is not Color-compatible")
#     if length < 3:
#         raise ValueError("value is not Color-compatible")
#     if 0 <= int(v[0]) <= 255 and 0 <= int(v[1]) <= 255 and \
#             0 <= int(v[2]) <= 255:
#         r = int(v[0])
#         g = int(v[1])
#         b = int(v[2])
#         if length >= 4 and 0 <= int(v[3]) <= 255:
#             a = int(v[3])
#         return Color(r, g, b, a)

#     raise ValueError("value is not Color-compatible")
