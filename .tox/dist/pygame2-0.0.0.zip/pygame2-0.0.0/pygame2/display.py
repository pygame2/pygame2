"""
"""

import pyglet
import pyglet.window


class PygameDisplay(object):

    _instance = None

    def __new__(class_, *args, **kwargs):
        if not isinstance(class_._instance, class_):
            class_._instance = object.__new__(class_, *args, **kwargs)
        return class_._instance

    def __init__(self, resolution, flags=0, depth=0):
        if not hasattr(self, "_initialized"):
            self._initialized = True
            self.resolution = resolution
            self.flags = flags
            self.depth = depth
            self.window = pyglet.window.Window()
            self.is_fullscreen = False

    def get_resolution(self):
        return self.resolution


def init():
    return None


def get_window():
    return PygameDisplay._instance.window


def set_mode(resolution, flags=0, depth=0):
    return PygameDisplay(resolution, flags, depth)


def set_caption(title, icontitle=""):
    PygameDisplay._instance.window.set_caption(title)


def get_caption():
    return PygameDisplay._instance.window.caption


def toggle_fullscreen():
    instance = PygameDisplay._instance
    instance.is_fullscreen = not instance.is_fullscreen
    instance.window.set_fullscreen(instance.is_fullscreen)


def update(*args, **kwargs):
    """NO-OP"""
    return None


def flip():
    """NO-OP"""
    return None


def get_surface():
    return PygameDisplay._instance


def quit():
    PygameDisplay._instance = None
    return PygameDisplay._instance


def get_init():
    return PygameDisplay._instance is not None


# def quit():
#     raise NotImplementedError()


# def set_mode(resolution=(0, 0), flags=0, depth=0):
#     raise NotImplementedError()


# def get_surface():
#     raise NotImplementedError()


# def flip():
#     raise NotImplementedError()


# def update(rectangle=None):
#     raise NotImplementedError()


# def get_driver():
#     raise NotImplementedError()


# def Info():
#     raise NotImplementedError()


# def get_wm_info():
#     raise NotImplementedError()


# def list_modes(depth, flags):
#     raise NotImplementedError()


# def mode_ok(size, flags=0, depth=None):
#     raise NotImplementedError()


# def gl_get_attribute(flag):
#     raise NotImplementedError()


# def gl_set_attribute(flag, value):
#     raise NotImplementedError()


# def get_active():
#     raise NotImplementedError()


# def iconify():
#     raise NotImplementedError()


# def toggle_fullscreen():
#     raise NotImplementedError()


# def set_gamma(red, green=None, blue=None):
#     raise NotImplementedError()


# def set_gamma_ramp(r, g, b):
#     raise NotImplementedError()


# def set_icon(icon):
#     raise NotImplementedError()


# def set_caption(title, icontitle=None):
#     raise NotImplementedError()


# def set_palette(palette=None):
#     raise NotImplementedError()
