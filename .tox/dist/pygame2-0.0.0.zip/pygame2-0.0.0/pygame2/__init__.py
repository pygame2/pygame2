# "required" modules
# #from pygame2.base import *
# #from pygame2.constants import *
# #from pygame2.version import *

# from pygame2.rect import Rect
# #from pygame2.compat import geterror
# #from pygame2.rwobject import encode_string, encode_file_path
# #import pygame2.surflock

# import pygame2.color
# Color = color.Color

# #import pygame2.bufferproxy
# #BufferProxy = bufferproxy.BufferProxy

from . import display
from . import image
from . import surface
from . import key


def init():
    display.init()
    key.init()


def quit():
    import sys
    sys.exit()
