import pyglet
# from pygame2.color import Color
from pygame2.rect import Rect
from pyglet.image import ImageData, SolidColorImagePattern
from PIL import Image as PIL_Image
from PIL.ImageDraw import Draw as PIL_Draw
from threading import Lock


__all__ = ['SubSurfaceData', 'Surface']


class SubSurfaceData:
    pass


class Surface:
    """
    Fundamental unit of graphics data for pygame2 games.  it is essentially a
    wrapper around pyglet images
    """

    def __init__(self, size, flags=0, depth=0, masks=None):
        w, h = (int(i) for i in size)
        self._width = w
        self._height = h
        self._imagedata = pyglet.image.create(w, h)
        self._lock = Lock()

    @classmethod
    def from_imagedata(cls, imagedata):
        s = Surface((imagedata.width, imagedata.height))
        s._imagedata = imagedata
        return s

    def get_imagedata(self):
        return self._imagedata

    def get_lock(self):
        return self._lock

    def lock(self):
        self._lock.acquire()

    def unlock(self):
        self._lock.release()

    def _get_draw_context(self):
        """
        get a drawing context to make changes on the image data
        the return value must be deleted or lost.  do not hold on to it.
        """
        if self._lock.locked():
            image = self._imagedata
            format = image.format
            if format != 'RGB':
                format = 'RGBA'
            pitch = -(image.width * len(format))
            pil_image = PIL_Image.frombuffer(
                format, (image.width, image.height),
                image.get_data(format, pitch))
            draw = PIL_Draw(pil_image)
            return draw, pil_image
        else:
            print('pygame2 surfaces must be locked before opening draw context')
            raise Exception

    def fill(self, color, rect=None, special_flags=0):
        """
        0. lock the surface
        1. get the image_data
        2. fill the image data region
        3. transform imagedata into texture
        4. unlock surface

        image transformation is handled by pillow
        this is a very slow operation

        :param color:
        :type color:
        :param rect:
        :type rect:
        :param special_flags:
        :type special_flags:
        :return:
        :rtype:
        """
        with self._lock:
            # this needs to be replaced with a proper color class
            if len(color) == 3:
                color = color[0], color[1], color[2], 0
            if rect is None:
                patt = SolidColorImagePattern(color)
                self._imagedata = patt.create_image(self._width,
                                                     self._height)
            else:
                image = self._imagedata
                draw, pil_image = self._get_draw_context()
                draw.rectangle(rect, color)
                image.set_data(image.format, image.pitch, pil_image.tostring())
                del draw

    def blit(self, source, dest, area=None, special_flags=0):
        if isinstance(source, Surface):
            lock = None
            x, y = dest[:2]
            if area is not None:
                lock = source.get_lock()
                source = source.get_region(area)
            with self._lock:
                if lock:
                    lock.acquire()
                self._imagedata.blit_into(source, x, y, 0)
                if lock:
                    lock.release()

            raise NotImplementedError
            # elif isinstance(source, DisplaySurface):
            #     """
            #     add destination, area, flags to the display 'blit queue
            #     """
            #     raise NotImplementedError

    def get_rect(self, **kwargs):
        return Rect(0, 0, self._width, self._height)

    def get_size(self):
        return self._imagedata.width, self._imagedata.height

    def get_width(self):
        return self._imagedata.width

    def get_height(self):
        return self._imagedata.height

    def get_region(self, area):
        """
        Get a region of the Surface's ImageData

        :param area: pygame2.Rect
        :rtype: pyglet.ImageDataRegion
        """
        return self._imagedata.get_region(*area)

#     def __del__(self):
#         pass

#     def __repr__(self):
#         pass

#     def _get_default_masks(self, bpp, alpha):
#         pass

#     def convert_alpha(self, srcsurf=None):
#         pass

#     def crop_to_surface(self, r):
#         pass

#     def get_pixels(self):
#         pass

#     def _from_sdl_surface(cls, c_surface):
#         pass

#     def check_opengl(self):
#         pass

#     def check_surface(self):
#         pass

#     def is_pure_opengl(self):
#         pass

#     def set_at(self, pos, color):
#         pass

#     def _set_at(self, x, y, c_color):
#         pass

#     def get_at(self, pos):
#         pass

#     def get_at_mapped(self, pos):
#         pass

#     def _get_at(self, x, y):
#         pass

#     def subsurface(self, *rect):
#         pass

#     def set_colorkey(self, color=None, flags=0):
#         pass

#     def copy(self):
#         pass

#     def convert(self, arg=None, flags=0):
#         pass

#     def get_colorkey(self):
#         pass

#     def set_alpha(self, value=None, flags=0):
#         pass

#     def get_alpha(self):
#         pass

#     def get_bounding_rect(self, min_alpha=1):
#         pass

#     def get_flags(self):
#         pass

#     def get_bitsize(self):
#         pass

#     def get_bytesize(self):
#         pass

#     def get_palette(self):
#         pass

#     def get_palette_at(self, index):
#         pass

#     def set_palette(self, colors):
#         pass

#     def set_palette_at(self, index, rgb):
#         pass

#     def map_rgb(self, col):
#         pass

#     def unmap_rgb(self, mapped_int):
#         pass

#     def set_clip(self, rect):
#         pass

#     def get_clip(self):
#         pass

#     def get_parent(self):
#         pass

#     def get_abs_parent(self):
#         pass

#     def get_offset(self):
#         pass

#     def get_abs_offset(self):
#         pass

#     def get_pitch(self):
#         pass

#     def get_masks(self):
#         pass

#     def set_masks(self, masks):
#         pass

#     def get_shifts(self):
#         pass

#     def set_shifts(self, shifts):
#         pass

#     def get_losses(self):
#         pass

#     def get_view(self, kind):
#         pass

#     def get_buffer(self):
#         pass

#     def scroll(self, dx=0, dy=0):
#         pass


# class SurfaceNoFree(Surface):
#     pass
