import pygame2
import pyglet
import collections
import functools

__all__ = ['get_focused',
           'get_pressed',
           'get_mods',
           'set_repeat',
           'get_repeat',
           'name']

_initialized = False
_keyhandler = None


class KeyStateHandler:
    def __init__(self):
        self.keys = collections.OrderedDict()
        for symbol in pyglet.window.key._key_names.keys():
            self.keys[symbol] = False

    def on_key_press(self, symbol, modifiers):
        self.keys[symbol] = True

    def on_key_release(self, symbol, modifiers):
        self.keys[symbol] = False


def requires_init(f):
    @functools.wraps(f)
    def wrap(*args, **kwargs):
        if _initialized:
            f(*args, **kwargs)
        else:
            raise Exception('key module must be initialized before get_pressed')
    return wrap


def requires_window_init(f):
    @functools.wraps(f)
    def wrap(*args, **kwargs):
        if pygame2.display.get_init():
            f(*args, **kwargs)
        else:
            raise Exception('pygame2 display mode must be set before key')
    return wrap


@requires_window_init
def init():
    global _initialized, _keyhandler
    win = pygame2.display.get_window()
    kbd = KeyStateHandler()
    win.push_handlers(kbd)
    _keyhandler = kbd
    _initialized = True


@requires_init
def get_focused():
    """true if the display is receiving keyboard input from the system

    :return: bool
    """
    raise NotImplementedError


@requires_init
def get_pressed():
    """get the state of all keyboard buttons

    :return: bools
    """
    return _keyhandler.keys.values()


def get_mods():
    """determine which modifier keys are being held

    :return: int
    """
    raise NotImplementedError


def set_mods():
    """temporarily set which modifier keys are pressed
    """
    raise NotImplementedError


def set_repeat():
    raise NotImplementedError


def get_repeat():
    raise NotImplementedError


def name(key):
    """get the name of a key identifier

    :param key: int of key code
    :return: str of descriptive key name
    """
    raise NotImplementedError


if __name__ == '__main__':
    pygame2.display.init()
    screeen = pygame2.display.set_mode((0, 0))
    init()
    pyglet.app.run()

