"""
Pygame handles all its event messaging through an event queue. The routines in
this module help you manage that event queue. The input queue is heavily
dependent on the pygame display module. If the display has not been initialized
and a video mode not set, the event queue will not really work.

The queue is a regular queue of pygame.event.EventTypepygame object for
representing SDL events event objects, there are a variety of ways to access
the events it contains. From simply checking for the existence of events, to
grabbing them directly off the stack.

All events have a type identifier. This event type is in between the values of
NOEVENT and NUMEVENTS. All user defined events can have the value of USEREVENT
or higher. It is recommended make sure your event id's follow this system.

To get the state of various input devices, you can forego the event queue and
access the input devices directly with their appropriate modules; mouse, key,
and joystick. If you use this method, remember that pygame requires some form
of communication with the system window manager and other parts of the
platform. To keep pygame in synch with the system, you will need to call
pygame.event.pump() to keep everything current. You'll want to call this
function usually once per game loop.

The event queue offers some simple filtering. This can help performance
slightly by blocking certain event types from the queue, use the
pygame.event.set_allowed() and pygame.event.set_blocked() to work with this
filtering. All events default to allowed.

The event subsystem should be called from the main thread. If you want to post
events into the queue from other threads, please use the fastevent package.

Joysticks will not send any events until the device has been initialized.

An EventType event object contains an event type identifier and a set of
member data. The event object contains no method functions, just member data.
EventType objects are retrieved from the pygame event queue. You can create
your own new events with the pygame.event.Event() function.

Your program must take steps to keep the event queue from overflowing. If the
program is not clearing or getting all events off the queue at regular
intervals, it can overflow. When the queue overflows an exception is thrown.

All EventType instances have an event type identifier, accessible as the
EventType.type property. You may also get full access to the event object's
attributes through the EventType.__dict__ attribute. All other member lookups
will be passed through to the object's dictionary values.

While debugging and experimenting, you can print an event object for a quick
display of its type and members. Events that come from the system will have a
guaranteed set of member items based on the type. Here is a list of the event
attributes defined with each event type.

"""
# import logging

# # all sdl2 events
# from pygame2.constants import (
#     FIRSTEVENT, QUIT, APP_TERMINATING, APP_LOWMEMORY, APP_WILLENTERBACKGROUND,
#     APP_DIDENTERBACKGROUND, APP_WILLENTERFORREGROUND, APP_DIDENTERFOREGROUND,
#     WINDOWEVENT, SYSWMEVENT, KEYDOWN, KEYUP, TEXTEDITING, TEXTINPUT,
#     MOUSEMOTION, MOUSEBUTTONDOWN, MOUSEBUTTONUP, MOUSEWHEEL, JOYAXISMOTION,
#     JOYBALLMOTION, JOYHATMOTION, JOYBUTTONDOWN, JOYBUTTONUP, JOYDEVICEADDED,
#     JOYDEVICEREMOVED, FINGERDOWN, FINGERUP, FINGERMOTION, DOLLARGESTURE,
#     DOLLARRECORD, MULTIGESTURE, CLIPBOARDUPDATE, DROPFILE, RENDER_TARGETS_RESET,
#     USEREVENT, LASTEVENT)

# from sdl2.events import (
#     SDL_PumpEvents, SDL_PollEvent, SDL_WaitEvent, SDL_PeepEvents, SDL_Event,
#     SDL_FlushEvent, SDL_FlushEvents, SDL_PushEvent,
#     SDL_ADDEVENT, SDL_PEEKEVENT, SDL_GETEVENT)

# # TODO: import pygame 1 compatibility events


# __all__ = [
#     "EventType",
#     "Event",
#     "pump",
#     "get",
#     "poll",
#     "wait",
#     "peek",
#     "clear",
#     "event_name",
#     "get_blocked",
#     "set_blocked",
#     "set_allowed",
#     "get_grab",
#     "set_grab",
#     "post",
#     ]

# logger = logging.getLogger("pygame2.event")
# PTR = ctypes.pointer

# class EventType:
#     """
#     An event object
#     """

#     def __init__(self, event):
#         self._event = event

#         if not event:
#             self.type = None #NOEVENT
#             return

#         self.timestamp = event.timestamp
#         self.type = event.type

#         if self.type in (KEYDOWN, KEYUP):
#             # pygame1 definitions
#             self.key = event.key.keysym.sym
#             self.mod = event.key.keysym.mod
#             self.scancode = event.key.keysym.scancode
#             self.unicode = None

#             # pygame2 only
#             self.window_id = event.windowID
#             self.repeat = event.repeat

#         # pygame2 only
#         elif self.type == TEXTEDITING:
#             logger.debug("type %s not implemented", self.type)
#             return

#         # pygame2 only
#         elif self.type == TEXTINPUT:
#             self.window_id = event.windowID
#             self.test = event.text

#         elif self.type == MOUSEMOTION:
#             self.pos = event.x, event.y
#             self.rel = event.xrel, event.yrel
#             # TODO: buttons

#         elif self.type in (MOUSEBUTTONDOWN, MOUSEBUTTONUP):
#             self.pos = event.x, event.y
#             self.button = event.button

#             # pygame2 only
#             self.window_id = event.windowID

#         # pygame2 only
#         elif self.type == MOUSEWHEEL:
#             self.window_id = event.windowID
#             self.x = event.x
#             self.y = event.y

#         elif self.type == JOYAXISMOTION:
#             self.joy = event.which
#             self.axis = event.axis
#             # TODO: axis insanity

#         elif self.type == JOYBALLMOTION:
#             self.joy = event.which
#             self.ball = event.ball
#             self.rel = event.xrel, event.yrel

#         elif self.type == JOYHATMOTION:
#             logger.debug("type %s not implemented", self.type)
#             return

#         elif self.type in (JOYBUTTONDOWN, JOYBUTTONUP):
#             self.joy = event.which
#             self.button = event.button

#         # pygame2 only
#         elif self.type == JOYDEVICEADDED:
#             self.joy = event.which

#         # pygame2 only
#         elif self.type == JOYDEVICEREMOVED:
#             self.joy = event.which

#         # TODO: Controller Events

#         # pygame2 only
#         elif self.type in (FINGERDOWN, FINGERUP, FINGERMOTION):
#             # unlike other event types, coordinates are normalized
#             self.touchid = event.touchid
#             self.fingerid = event.fingerid
#             self.x = event.x
#             self.y = event.y
#             self.dx = event.dx
#             self.dy = event.dy
#             self.pressure = event.pressure

#         # pygame2 only
#         elif self.type == DOLLARGESTURE:
#             logger.debug("type %s not implemented", self.type)
#             return


#         # pygame2 only
#         elif self.type == DOLLARRECORD:
#             logger.debug("type %s not implemented", self.type)
#             return


#         # pygame2 only
#         elif self.type == MULTIGESTURE:
#             logger.debug("type %s not implemented", self.type)
#             return


#         # pygame2 only
#         elif self.type == DROPFILE:
#             logger.debug("type %s not implemented", self.type)
#             return


#         # pygame2 only
#         elif self.type == RENDER_TARGETS_RESET:
#             logger.debug("type %s not implemented", self.type)
#             return


#         # pygame2 only
#         elif self.type == USEREVENT:
#             logger.debug("type %s not implemented", self.type)
#             return


#         # pygame2 only
#         elif self.type == LASTEVENT:
#             logger.debug("type %s not implemented", self.type)
#             return


# def Event(type_id, attr_dict=None, **attrs):
#     """
#     Event(type, dict) -> EventType instance
#     """
#     pass


# def get_events(action, first, last):
#     """Get all the events in the SDL event queue

#     pump the event queue before calling this, or before many times in series

#     :param action: SDL action type
#     :type action: int
#     :param first: minimum value of the event type to be considered
#     :type first: int
#     :param last: maximum value of the event type to be considered;
#     :type last: int
#     :return: list of events
#     :rtype: list
#     """
#     evlist = list()

#     while True:
#         evarray = (SDL_Event * 10)()
#         ptr = ctypes.cast(evarray, PTR(SDL_Event))
#         ret = SDL_PeepEvents(ptr, 10, SDL_GETEVENT, first, last)
#         if ret <= 0:
#             break
#         evlist += list(evarray)[:ret]
#         if ret < 10:
#             break
#     return evlist


# def pump():
#     """internally process pygame event handlers

#     For each frame of your game, you will need to make some sort of call to
#     the event queue. This ensures your program can internally interact with
#     the rest of the operating system. If you are not using other event
#     functions in your game, you should call pygame.event.pump() to allow
#     pygame to handle internal actions.

#     This function is not necessary if your program is consistently processing
#     events on the queue through the other pygame.eventpygame module for
#     interacting with events and queues functions.

#     There are important things that must be dealt with internally in the
#     event queue. The main window may need to be repainted or respond to the
#     system. If you fail to make a call to the event queue for too long,
#     the system may decide your program has locked up.

#     :return: None
#     """
#     SDL_PumpEvents()


# def get(event_filter=None):
#     """get events from the queue

#     get() -> Eventlist
#     get(type) -> Eventlist
#     get(typelist) -> Eventlist

#     This will get all the messages and remove them from the queue. If a type
#     or sequence of types is given only those messages will be removed from
#     the queue.

#     If you are only taking specific events from the queue, be aware that the
#     queue could eventually fill up with the events you are not interested.

#     :param event_filter:
#     :type event_filter:
#     :return: event list
#     :rtype: list
#     """
#     first = FIRSTEVENT
#     last = LASTEVENT
#     if event_filter is not None:
#         raise NotImplementedError

#     SDL_PumpEvents()
#     for event in get_events(SDL_GETEVENT, first, last):
#         yield EventType(event)


# def poll():
#     """get a single event from the queue

#     poll() -> EventType instance

#     Returns a single event from the queue. If the event queue is empty an
#     event of type pygame.NOEVENT will be returned immediately. The returned
#     event is removed from the queue.

#     This can only be called from the thread that has set the video mode.

#     poll() is the favored way of receiving system events since it can be done
#     from the main loop and does not suspend the main loop while waiting on any
#     event to be posted.

#     TODO: how to handle NOEVENT?  None?

#     :return: event
#     :rtype: EventType
#     """
#     event = SDL_Event
#     if SDL_PollEvent(PTR(event)):
#         return EventType(event)
#     return None


# def wait():
#     """wait for a single event from the queue

#     wait() -> EventType instance

#     Returns a single event from the queue. If the queue is empty this
#     function will wait until one is created. The event is removed from the
#     queue once it has been returned. While the program is waiting it will
#     sleep in an idle state. This is important for programs that want to share
#     the system with other applications.

#     This can only be called from the thread that has set the video mode.

#     :return: event
#     :rtype: EventType
#     """
#     event = SDL_Event
#     if not SDL_WaitEvent(PTR(event)):
#         raise Exception
#     return Event(event)


# def peek(types=None):
#     """test if event types are waiting on the queue

#     peek(type) -> bool
#     peek(typelist) -> bool

#     Returns true if there are any events of the given type waiting on the
#     queue. If a sequence of event types is passed, this will return True if
#     any of those events are on the queue.

#     :param types:
#     :type types:
#     :return: bool if event types are waiting on the queue
#     :rtype: bool
#     """
#     first = FIRSTEVENT
#     last = LASTEVENT
#     if event_filter is not None:
#         raise NotImplementedError

#     SDL_PumpEvents()
#     return get_events(SDL_PEEKEVENT, first, last)


# def clear(event_filter=None):
#     """remove all events from the queue

#     clear() -> None
#     clear(type) -> None
#     clear(typelist) -> None

#     Remove all events or events of a specific type from the queue. This has
#     the same effect as pygame.event.get() except nothing is returned. This
#     can be slightly more efficient when clearing a full event queue.

#     :return: None
#     """
#     if event_filter is not None:
#         raise NotImplementedError

#     SDL_PumpEvents()
#     SDL_FlushEvents()


# def event_name():
#     """get the string name from and event id

#     event_name(type) -> string

#     Pygame uses integer ids to represent the event types. If you want to
#     report these types to the user they should be converted to strings. This
#     will return a the simple name for an event type. The string is in the
#     WordCap style.

#     :return: name of event type
#     :rtype: str
#     """
#     pass


# def get_blocked(event_types):
#     """test if a type of event is blocked from the queue

#     get_blocked(type) -> bool

#     Returns true if the given event type is blocked from the queue.

#     :param event_types:
#     :type event_types:
#     :return: whether a type of event is blocked from the queue or not
#     :rtype: bool
#     """
#     pass


# def set_blocked(event_types):
#     """control which events are allowed on the queue

#     set_blocked(type) -> None
#     set_blocked(typelist) -> None
#     set_blocked(None) -> None

#     The given event types are not allowed to appear on the event queue. By
#     default all events can be placed on the queue. It is safe to disable an
#     event type multiple times.

#     If None is passed as the argument, this has the opposite effect and ALL
#     of the event types are allowed to be placed on the queue.

#     :param event_types:
#     :type event_types:
#     :return: None
#     """
#     pass


# def set_allowed(event_types):
#     """control which events are allowed on the queue

#     set_allowed(type) -> None
#     set_allowed(typelist) -> None
#     set_allowed(None) -> None

#     The given event types are allowed to appear on the event queue. By
#     default all events can be placed on the queue. It is safe to enable an
#     event type multiple times.

#     If None is passed as the argument, NONE of the event types are allowed to
#     be placed on the queue.

#     :param event_types:
#     :type event_types:
#     :return: None
#     """
#     pass


# def get_grab():
#     """control the sharing of input devices with other applications

#     This function no longer has meaning since SDL2 is a native multi-window
#     aware
#     """
#     raise NotImplementedError


# def set_grab(value):
#     """test if the program is sharing input devices

#     This function no longer has meaning since SDL2 is a native multi-window
#     aware
#     """
#     raise NotImplementedError


# def post(event):
#     """place a new event on the queue

#     post(Event) -> bool

#     This places a new event at the end of the event queue. These Events will
#     later be retrieved from the other queue functions.

#     This is usually used for placing pygame.USEREVENT events on the queue.
#     Although any type of event can be placed, if using the system event types
#     your program should be sure to create the standard attributes with
#     appropriate values.

#     pygame1 note: pygame1 returns None, pygame2 will return a boolean

#     :param event:
#     :type event or list:
#     :return: True on success, False if the event was filtered
#     """
#     return bool(SDL_PushEvent(PTR(event)))
