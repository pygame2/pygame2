from distutils.core import setup

setup(name='pygame2',
      version='0.0.0',
      packages=['pygame2'],
      )
